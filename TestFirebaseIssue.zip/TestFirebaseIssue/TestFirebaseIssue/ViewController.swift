//
//  ViewController.swift
//  TestFirebaseIssue
//
//  Created by Mike on 9/6/19.
//  Copyright © 2019 Veritas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

