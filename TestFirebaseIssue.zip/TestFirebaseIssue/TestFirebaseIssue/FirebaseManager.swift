//
//  FirebaseManager.swift
//  BattleBuddy
//
//  Created by Mike on 7/8/19.
//  Copyright © 2019 Veritas. All rights reserved.
//

import Foundation
import Firebase
import FirebaseStorage
import FirebaseUI
import FirebaseFirestore
import FirebaseAuth


class FirebaseManager {
    private lazy var db = Firestore.firestore()

    init() {
        FirebaseApp.configure()

        // Uncomment this out for debugging purposes.
         FirebaseConfiguration.shared.setLoggerLevel(.max)
    }

    func initializeSession() {
        print("Initializing anonymous session...")

        Auth.auth().signInAnonymously() { (authResult, error) in
            if let error = error {
                print("Anonymous auth failed with error: ", error)
            } else {
                print("Anonymous auth succeeded.")
            }

            self.getAllFirearms()
        }
    }

    func getAllFirearms() {
        db.collection("firearm").getDocuments() { (querySnapshot, err) in
            if let error = err {
                print("Failed to get all firearms w/ error: ", error.localizedDescription)
                return
            }
            guard let snapshot = querySnapshot else {
                print("No snapshot.")
                return
            }
            print("Successfully fetched \(String(snapshot.documents.count)) firearms.")
        }
    }
}
